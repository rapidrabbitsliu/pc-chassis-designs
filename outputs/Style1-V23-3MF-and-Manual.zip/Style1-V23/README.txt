V23最新15件九盘3MF及修订2说明书。插图直接提取自本包3MF。打开工程后重新切片。在线说明书：https://rapidrabbitsliu.github.io/pc-chassis-designs/
未发送打印；实物配合和承载需测试。