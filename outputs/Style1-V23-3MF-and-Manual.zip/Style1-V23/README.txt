V23最新15件九盘3MF与对应离线说明书。打开3MF后请重新切片；无需运行建模脚本。在线说明书：https://rapidrabbitsliu.github.io/pc-chassis-designs/
未发送打印，承载和实物配合需测试。